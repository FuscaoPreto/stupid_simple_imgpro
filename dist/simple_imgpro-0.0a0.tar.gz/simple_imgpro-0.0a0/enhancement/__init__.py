import numpy as np
import matplotlib.pyplot as plt
import matplotlib.image as mpimg